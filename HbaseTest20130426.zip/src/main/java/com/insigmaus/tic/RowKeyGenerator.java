package com.insigmaus.tic;


/** 
 * 
 * @author  insigmaus12
 * @version V1.0  Create Time: Apr 26, 2013
 */

public class RowKeyGenerator {

    public static int generateRowKey(int symbolId, int timeStamp) {
        int rowKey = 0;

        rowKey = (symbolId + 1 * 1000000) + ((timeStamp - 1312000000) / 60);

        if (rowKey < 0) {
            throw new RuntimeException("The rowKey outbound of Integer rang");
        }

        return rowKey;
    }

}


