package com.insigmaus.tic;


/** 
 * 
 * @author  insigmaus12
 * @version V1.0  Create Time: Apr 26, 2013
 */

public class RowKeyGenerator {

    public static int generateRowKey(int symbolId, int offset) {
        int rowKey = 0;

        rowKey = symbolId + offset;

        if (rowKey < 0) {
            throw new RuntimeException("The rowKey outbound of Integer rang");
        }

        return rowKey;
    }

}


