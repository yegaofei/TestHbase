package com.insigmaus.tic;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

/** 
 * 
 * @author  insigmaus12
 * @version V1.0  Create Time: Apr 27, 2013
 */

public class TicDataReader implements Runnable {

    static final byte[] COLUMN_TIME = Bytes.toBytes("TimeStamp");
    static final byte[] COLUMN_FLAGS = Bytes.toBytes("flag");
    static final byte[] COLUMN_EXH_TIME = Bytes.toBytes("ExchangeTime");
    static final byte[] COLUMN_SEQUENCENUMBER = Bytes.toBytes("SequenceNumber");
    static final byte[] COLUMN_LINEID = Bytes.toBytes("LineID");
    static final byte[] COLUMN_SEQUENCESEIRES = Bytes.toBytes("SequenceSeires");
    static final byte[] COLUMN_SEQUENCEQAULIFIER = Bytes.toBytes("SequenceQaulifier");
    static final byte[] COLUMN_TRADEEXCHANGE = Bytes.toBytes("TradeExchange");
    static final byte[] COLUMN_TRADEPRICE = Bytes.toBytes("TradePrice");
    static final byte[] COLUMN_VWAP = Bytes.toBytes("VWAP");
    static final byte[] COLUMN_TRADEVOLUME = Bytes.toBytes("TradeVolume");
    static final byte[] COLUMN_QUALIFIERS = Bytes.toBytes("Qualifiers");
    static final byte[] COLUMN_CUMVOLUME = Bytes.toBytes("CumVolume");
    static final byte[] COLUMN_VOLQUALIFIERS = Bytes.toBytes("Volqualifiers");
    static final byte[] COLUMN_ASK_EXCHANGE = Bytes.toBytes("AskExchange");
    static final byte[] COLUMN_BID_EXCHANGE = Bytes.toBytes("BidExchange");
    static final byte[] COLUMN_BID_PRICE = Bytes.toBytes("BidPrice");
    static final byte[] COLUMN_ASK_PRICE = Bytes.toBytes("AskPrice");
    static final byte[] COLUMN_BID_SIZE = Bytes.toBytes("BidSize");
    static final byte[] COLUMN_ASK_SIZE = Bytes.toBytes("AskSize");

    private static final int HTABLE_BUFFER_SIZE = 1024 * 1024 * 20;

    public static final byte[] FAMILY_NAME = Bytes.toBytes("cf");

    private int startIndex;

    private int endIndex;

    private HTable ticTradetable;

    private HTable symbolTable;

    private HTable ticQuoteTable;

    private static final String TIC_TRADE_TABLE_NAME = "Tic_Trade";

    private static final String SYMBOL_TABLE_NAME = "Symbol";

    private static final byte[] SYMBOL_FAMILY_NAME = Bytes.toBytes("ID");

    private static final String TIC_QUOTE_TABLE_NAME = "Tic_Quote";

    private static final byte[] SYMBOL_ID_QUALIFIER_NAME = Bytes.toBytes("S");

    private boolean flushCommits = true;

    private volatile Configuration conf;

    private CountDownLatch countDownLatch = null;

    private SymbolCount[] symbolCountArray = null;

    private List<String> symbolList = null;

    private int fetchRecodeCount = 0;

    public TicDataReader(Configuration conf, List<String> symbolList) {
        this.conf = conf;
        this.symbolList = symbolList;
    }

    public void run() {
        try {
            initTables();
            scanTable();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            if (this.countDownLatch != null) {
                this.countDownLatch.countDown();
            }
        }
    }

    private void scanTable() throws IOException {
        if (symbolList == null) {
            return;
        }

        for (String symbol : symbolList) {
            long startTime = System.currentTimeMillis();
            Get getSymbolId = new Get(symbol.getBytes());
            Result r = symbolTable.get(getSymbolId);
            KeyValue kv = r.getColumnLatest(SYMBOL_FAMILY_NAME, SYMBOL_ID_QUALIFIER_NAME);
            if (kv != null) {
                byte[] v = kv.getValue();
                int symbolId = Bytes.toInt(v);
                int baseKey = RowKeyGenerator.generateRowKey(symbolId, 0);
                
                int key = baseKey;
                while(true){
                    Get get = new Get(Bytes.toBytes(key));
                    Result result = this.ticQuoteTable.get(get);
                    if(result.size() > 0){
                        key++;
                        fetchRecodeCount ++;
                        continue;
                    } else {
                        break;
                    }
                }
                
                key = baseKey;
                while(true){
                    Get get = new Get(Bytes.toBytes(key));
                    Result result = this.ticTradetable.get(get);
                    if(result.size() > 0){
                        key++;
                        fetchRecodeCount++;
                        continue;
                    } else {
                        break;
                    }
                }

                long timeSpend = System.currentTimeMillis() - startTime;
                double performance = (double) fetchRecodeCount / (double) timeSpend * 1000;
                System.out.println("Fetch " + fetchRecodeCount + " rows for Symbol " + symbol
                        + " performance is " + performance + " r/s");
            }
        }
    }

    private void initTables() throws IOException {
        this.ticTradetable = new HTable(conf, TIC_TRADE_TABLE_NAME);
        this.ticTradetable.setWriteBufferSize(HTABLE_BUFFER_SIZE);
        this.ticTradetable.setAutoFlush(false);

        this.symbolTable = new HTable(conf, SYMBOL_TABLE_NAME);
        this.symbolTable.setAutoFlush(false);

        this.ticQuoteTable = new HTable(conf, TIC_QUOTE_TABLE_NAME);
        this.ticQuoteTable.setWriteBufferSize(HTABLE_BUFFER_SIZE);
        this.ticQuoteTable.setAutoFlush(false);
    }

    public int getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }

    public int getEndIndex() {
        return endIndex;
    }

    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
    }

    public HTable getTicTradetable() {
        return ticTradetable;
    }

    public void setTicTradetable(HTable ticTradetable) {
        this.ticTradetable = ticTradetable;
    }

    public HTable getSymbolTable() {
        return symbolTable;
    }

    public void setSymbolTable(HTable symbolTable) {
        this.symbolTable = symbolTable;
    }

    public HTable getTicQuoteTable() {
        return ticQuoteTable;
    }

    public void setTicQuoteTable(HTable ticQuoteTable) {
        this.ticQuoteTable = ticQuoteTable;
    }

    public boolean isFlushCommits() {
        return flushCommits;
    }

    public void setFlushCommits(boolean flushCommits) {
        this.flushCommits = flushCommits;
    }

    public Configuration getConf() {
        return conf;
    }

    public void setConf(Configuration conf) {
        this.conf = conf;
    }

    public CountDownLatch getCountDownLatch() {
        return countDownLatch;
    }

    public void setCountDownLatch(CountDownLatch countDownLatch) {
        this.countDownLatch = countDownLatch;
    }

    public SymbolCount[] getSymbolCountArray() {
        return symbolCountArray;
    }

    public void setSymbolCountArray(SymbolCount[] symbolCountArray) {
        this.symbolCountArray = symbolCountArray;
    }

}


