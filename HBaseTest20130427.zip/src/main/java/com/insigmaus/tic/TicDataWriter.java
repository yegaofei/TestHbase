package com.insigmaus.tic;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

/** 
 * 
 * @author  insigmaus12
 * @version V1.0  Create Time: Apr 27, 2013
 */

public class TicDataWriter implements Runnable {

    static final byte[] COLUMN_TIME = Bytes.toBytes("TimeStamp");
    static final byte[] COLUMN_FLAGS = Bytes.toBytes("flag");
    static final byte[] COLUMN_EXH_TIME = Bytes.toBytes("ExchangeTime");
    static final byte[] COLUMN_SEQUENCENUMBER = Bytes.toBytes("SequenceNumber");
    static final byte[] COLUMN_LINEID = Bytes.toBytes("LineID");
    static final byte[] COLUMN_SEQUENCESEIRES = Bytes.toBytes("SequenceSeires");
    static final byte[] COLUMN_SEQUENCEQAULIFIER = Bytes.toBytes("SequenceQaulifier");
    static final byte[] COLUMN_TRADEEXCHANGE = Bytes.toBytes("TradeExchange");
    static final byte[] COLUMN_TRADEPRICE = Bytes.toBytes("TradePrice");
    static final byte[] COLUMN_VWAP = Bytes.toBytes("VWAP");
    static final byte[] COLUMN_TRADEVOLUME = Bytes.toBytes("TradeVolume");
    static final byte[] COLUMN_QUALIFIERS = Bytes.toBytes("Qualifiers");
    static final byte[] COLUMN_CUMVOLUME = Bytes.toBytes("CumVolume");
    static final byte[] COLUMN_VOLQUALIFIERS = Bytes.toBytes("Volqualifiers");
    static final byte[] COLUMN_ASK_EXCHANGE = Bytes.toBytes("AskExchange");
    static final byte[] COLUMN_BID_EXCHANGE = Bytes.toBytes("BidExchange");
    static final byte[] COLUMN_BID_PRICE = Bytes.toBytes("BidPrice");
    static final byte[] COLUMN_ASK_PRICE = Bytes.toBytes("AskPrice");
    static final byte[] COLUMN_BID_SIZE = Bytes.toBytes("BidSize");
    static final byte[] COLUMN_ASK_SIZE = Bytes.toBytes("AskSize");

    private static final int HTABLE_BUFFER_SIZE = 1024 * 1024 * 20;

    public static final byte[] FAMILY_NAME = Bytes.toBytes("cf");

    private int startIndex;

    private int endIndex;

    private HTable ticTradetable;

    private HTable symbolTable;

    private HTable ticQuoteTable;

    private static final String TIC_TRADE_TABLE_NAME = "Tic_Trade";

    private static final String SYMBOL_TABLE_NAME = "Symbol";

    private static final byte[] SYMBOL_FAMILY_NAME = Bytes.toBytes("ID");

    private static final String TIC_QUOTE_TABLE_NAME = "Tic_Quote";

    private static final byte[] SYMBOL_ID_QUALIFIER_NAME = Bytes.toBytes("S");

    private boolean flushCommits = true;

    private volatile Configuration conf;

    private CountDownLatch countDownLatch = null;

    private SymbolCount[] symbolCountArray = null;

    public SymbolCount[] getSymbolCountArray() {
        return symbolCountArray;
    }

    public void setSymbolCountArray(SymbolCount[] symbolCountArray) {
        this.symbolCountArray = symbolCountArray;
    }

    private TicDataGenerate tdg = null;

    public TicDataWriter(int startIndex, int endIndex) {
        super();
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.tdg = new TicDataGenerate();
    }

    public void run() {
        if (symbolCountArray == null) {
            return;
        }
        try {
            initTables();
            ticDataWrite();
            testTakedown();
        } catch (Exception e1) {
            e1.printStackTrace();
        } finally {
            if (this.countDownLatch != null) {
                this.countDownLatch.countDown();
            }
        }
    }

    private void ticDataWrite() throws IOException {
        for (int i = this.startIndex; i < this.endIndex; i++) {
            SymbolCount symbolCount = symbolCountArray[i];
            String symbol = symbolCount.getSymbol();
            int count = symbolCount.getCount();

            // System.out.println("Inserting symbol " + symbol);
            // insert into symbol table
            int symbolId = Math.abs(symbol.hashCode());
            insertSymbolData(symbol, symbolId);

            int tradeCount = Math.round(count / 10);
            TicTradeCID[] ticTrade = this.tdg.generateTicTradeCID(symbol, tradeCount);

            List<Put> putList = new LinkedList<Put>();
            for (int k = 0; k < ticTrade.length; k++) {
                TicTradeCID trade = ticTrade[k];
                byte[] key = Bytes.toBytes(RowKeyGenerator.generateRowKey(symbolId, k));
                Put put = new Put(key);
                // put.add(FAMILY_NAME, COLUMN_TIME, trade.gettTime(),
                // Bytes.toBytes(trade.gettTime()));
                // put.add(FAMILY_NAME, COLUMN_FLAGS, trade.gettTime(),
                // Bytes.toBytes(trade.getuFlags()));
                // put.add(FAMILY_NAME, COLUMN_EXH_TIME, trade.gettTime(),
                // Bytes.toBytes(trade.getExchangeTime()));
                // put.add(FAMILY_NAME, COLUMN_SEQUENCENUMBER, trade.gettTime(),
                // Bytes.toBytes(trade.getSequenceNumber()));
                // put.add(FAMILY_NAME, COLUMN_LINEID, trade.gettTime(),
                // Bytes.toBytes(trade.getLineID()));
                // put.add(FAMILY_NAME, COLUMN_SEQUENCESEIRES, trade.gettTime(),
                // Bytes.toBytes(trade.getSequenceSeries()));
                // put.add(FAMILY_NAME, COLUMN_SEQUENCEQAULIFIER,
                // trade.gettTime(),
                // trade.getSecqualifiers());
                // put.add(FAMILY_NAME, COLUMN_TRADEEXCHANGE, trade.gettTime(),
                // new String(trade.getcTradeExchange()).getBytes());
                // put.add(FAMILY_NAME, COLUMN_TRADEPRICE, trade.gettTime(),
                // Bytes.toBytes(trade.getdTradePrice()));
                // put.add(FAMILY_NAME, COLUMN_VWAP, trade.gettTime(),
                // Bytes.toBytes(trade.getdVWAP()));
                // put.add(FAMILY_NAME, COLUMN_TRADEVOLUME, trade.gettTime(),
                // Bytes.toBytes(trade.getiTradeVolume()));
                // put.add(FAMILY_NAME, COLUMN_QUALIFIERS, trade.gettTime(),
                // trade.getQualifiers());
                // put.add(FAMILY_NAME, COLUMN_CUMVOLUME, trade.gettTime(),
                // Bytes.toBytes(trade.getuCumVolume()));
                // put.add(FAMILY_NAME, COLUMN_VOLQUALIFIERS, trade.gettTime(),
                // trade.getVolqualifiers());
                put.add(FAMILY_NAME, COLUMN_TIME, Bytes.toBytes(trade.gettTime()));
                put.add(FAMILY_NAME, COLUMN_FLAGS,
                        Bytes.toBytes(trade.getuFlags()));
                put.add(FAMILY_NAME, COLUMN_EXH_TIME,
                        Bytes.toBytes(trade.getExchangeTime()));
                put.add(FAMILY_NAME, COLUMN_SEQUENCENUMBER,
                        Bytes.toBytes(trade.getSequenceNumber()));
                put.add(FAMILY_NAME, COLUMN_LINEID,
                        Bytes.toBytes(trade.getLineID()));
                put.add(FAMILY_NAME, COLUMN_SEQUENCESEIRES,
                        Bytes.toBytes(trade.getSequenceSeries()));
                put.add(FAMILY_NAME, COLUMN_SEQUENCEQAULIFIER,
                        trade.getSecqualifiers());
                put.add(FAMILY_NAME, COLUMN_TRADEEXCHANGE,
                        new String(trade.getcTradeExchange()).getBytes());
                put.add(FAMILY_NAME, COLUMN_TRADEPRICE,
                        Bytes.toBytes(trade.getdTradePrice()));
                put.add(FAMILY_NAME, COLUMN_VWAP, Bytes.toBytes(trade.getdVWAP()));
                put.add(FAMILY_NAME, COLUMN_TRADEVOLUME,
                        Bytes.toBytes(trade.getiTradeVolume()));
                put.add(FAMILY_NAME, COLUMN_QUALIFIERS, trade.getQualifiers());
                put.add(FAMILY_NAME, COLUMN_CUMVOLUME,
                        Bytes.toBytes(trade.getuCumVolume()));
                put.add(FAMILY_NAME, COLUMN_VOLQUALIFIERS,
                        trade.getVolqualifiers());
                putList.add(put);

                if ((k % 500 == 0) && (k > 0)) {
                    try {
                        this.ticTradetable.put(putList);
                        putList = new LinkedList<Put>();
                    } catch (IOException e) {
                        k--;
                        putList.remove(putList.size() - 1);
                        continue;
                    }
                }
            }

            if (putList.size() > 0) {
                try {
                    this.ticTradetable.put(putList);
                } catch (IOException e) {
                    this.ticQuoteTable.put(putList); // try again if
                    // timeout
                }
            }

            TicQuoteCID[] ticQuote = this.tdg.generateTicQuoteCIDArray(symbol, count - tradeCount);
            List<Put> putListQuote = new LinkedList<Put>();
            for (int k = 0; k < ticQuote.length; k++) {
                TicQuoteCID quote = ticQuote[k];
                byte[] key = Bytes.toBytes(RowKeyGenerator.generateRowKey(symbolId, k));
                Put put = new Put(key);
                // put.add(FAMILY_NAME, COLUMN_TIME, quote.gettTime(),
                // Bytes.toBytes(quote.gettTime()));
                // put.add(FAMILY_NAME, COLUMN_FLAGS, quote.gettTime(),
                // Bytes.toBytes(quote.getuFlags()));
                // put.add(FAMILY_NAME, COLUMN_EXH_TIME, quote.gettTime(),
                // Bytes.toBytes(quote.getExchangeTime()));
                // put.add(FAMILY_NAME, COLUMN_SEQUENCENUMBER, quote.gettTime(),
                // Bytes.toBytes(quote.getSequenceNumber()));
                // put.add(FAMILY_NAME, COLUMN_LINEID, quote.gettTime(),
                // Bytes.toBytes(quote.getLineID()));
                // put.add(FAMILY_NAME, COLUMN_SEQUENCESEIRES, quote.gettTime(),
                // Bytes.toBytes(quote.getSequenceSeries()));
                // put.add(FAMILY_NAME, COLUMN_SEQUENCEQAULIFIER,
                // quote.gettTime(),
                // quote.getSecqualifiers());
                // put.add(FAMILY_NAME, COLUMN_ASK_EXCHANGE, quote.gettTime(),
                // new String(quote.getcAskExchange()).getBytes());
                // put.add(FAMILY_NAME, COLUMN_BID_EXCHANGE, quote.gettTime(),
                // new String(quote.getcBidExchange()).getBytes());
                // put.add(FAMILY_NAME, COLUMN_BID_PRICE, quote.gettTime(),
                // Bytes.toBytes(quote.getdBidPrice()));
                // put.add(FAMILY_NAME, COLUMN_ASK_PRICE, quote.gettTime(),
                // Bytes.toBytes(quote.getdAskPrice()));
                // put.add(FAMILY_NAME, COLUMN_BID_SIZE, quote.gettTime(),
                // Bytes.toBytes(quote.getiBidSize()));
                // put.add(FAMILY_NAME, COLUMN_ASK_SIZE, quote.gettTime(),
                // Bytes.toBytes(quote.getiAskSize()));
                put.add(FAMILY_NAME, COLUMN_TIME, Bytes.toBytes(quote.gettTime()));
                put.add(FAMILY_NAME, COLUMN_FLAGS,
                        Bytes.toBytes(quote.getuFlags()));
                put.add(FAMILY_NAME, COLUMN_EXH_TIME,
                        Bytes.toBytes(quote.getExchangeTime()));
                put.add(FAMILY_NAME, COLUMN_SEQUENCENUMBER,
                        Bytes.toBytes(quote.getSequenceNumber()));
                put.add(FAMILY_NAME, COLUMN_LINEID,
                        Bytes.toBytes(quote.getLineID()));
                put.add(FAMILY_NAME, COLUMN_SEQUENCESEIRES,
                        Bytes.toBytes(quote.getSequenceSeries()));
                put.add(FAMILY_NAME, COLUMN_SEQUENCEQAULIFIER,
                        quote.getSecqualifiers());
                put.add(FAMILY_NAME, COLUMN_ASK_EXCHANGE,
                        new String(quote.getcAskExchange()).getBytes());
                put.add(FAMILY_NAME, COLUMN_BID_EXCHANGE,
                        new String(quote.getcBidExchange()).getBytes());
                put.add(FAMILY_NAME, COLUMN_BID_PRICE,
                        Bytes.toBytes(quote.getdBidPrice()));
                put.add(FAMILY_NAME, COLUMN_ASK_PRICE,
                        Bytes.toBytes(quote.getdAskPrice()));
                put.add(FAMILY_NAME, COLUMN_BID_SIZE,
                        Bytes.toBytes(quote.getiBidSize()));
                put.add(FAMILY_NAME, COLUMN_ASK_SIZE,
                        Bytes.toBytes(quote.getiAskSize()));
                putListQuote.add(put);

                if ((k % 500 == 0) && (k > 0)) {
                    try{
                        this.ticQuoteTable.put(putListQuote);
                        putListQuote = new LinkedList<Put>();
                    }catch (IOException e) {
                        k--;
                        putListQuote.remove(putListQuote.size() - 1);
                        continue;
                    }
                }
            }

            // long tStart = System.currentTimeMillis();
            if (putListQuote.size() > 0) {
                try {
                    this.ticQuoteTable.put(putListQuote);
                } catch (IOException e) {
                    this.ticQuoteTable.put(putListQuote); // try again if
                                                          // timeout
                }
            } 
            // long spendTime = System.currentTimeMillis() - tStart;
            // if (spendTime > 0) {
            // // System.out.print("insert " + putListQuote.size() +
            // // " TicQuoteCIDs by spending "
            // // + spendTime);
            // // double performance = (double) putListQuote.size() / (double)
            // spendTime * 1000;
            // // System.out.println(",    Performance is " + performance +
            // // " r/s");
            // //System.out.println(performance);
            // }
        }
    }

    // we don't yet check if the symbol exists or not.
    private void insertSymbolData(String symbol, int id) throws IOException {
        // System.out.println("Start inserting symbol " + symbol +
        // " with id " + id);
        byte[] key = symbol.getBytes();
        Put put = new Put(key);
        put.add(SYMBOL_FAMILY_NAME, SYMBOL_ID_QUALIFIER_NAME, Bytes.toBytes(id));
        this.symbolTable.put(put);

        // System.out.println("End inserting symbol " + symbol + " with id "
        // + id);
    }

    private void initTables() throws IOException {
        this.ticTradetable = new HTable(conf, TIC_TRADE_TABLE_NAME);
        this.ticTradetable.setWriteBufferSize(HTABLE_BUFFER_SIZE);
        this.ticTradetable.setAutoFlush(false);

        this.symbolTable = new HTable(conf, SYMBOL_TABLE_NAME);
        this.symbolTable.setAutoFlush(true);

        this.ticQuoteTable = new HTable(conf, TIC_QUOTE_TABLE_NAME);
        this.ticQuoteTable.setWriteBufferSize(HTABLE_BUFFER_SIZE);
        this.ticQuoteTable.setAutoFlush(false);
    }

    public CountDownLatch getCountDownLatch() {
        return countDownLatch;
    }

    public void setCountDownLatch(CountDownLatch countDownLatch) {
        this.countDownLatch = countDownLatch;
    }

    public Configuration getConf() {
        return conf;
    }

    public void setConf(Configuration conf) {
        this.conf = conf;
    }

    private void testTakedown() throws IOException {
        if (flushCommits) {
            this.ticTradetable.flushCommits();
            this.ticQuoteTable.flushCommits();
            this.symbolTable.flushCommits();
        }
        this.ticTradetable.close();
        this.ticQuoteTable.close();
        this.symbolTable.close();
    }

}


